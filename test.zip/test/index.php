<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="/test/css/style.css">
	<link rel="stylesheet" href="https://fonts.google.com/specimen/Roboto?query=robo">
</head>
	<body>
		<div class="main-container">
			<div class="left">
				<div class="content-container">
					<p>PHOTO FROM: IMGUR</p>
				</div>
			</div>

			<div class="right">
				<div class="content-container">
					<h2>Interstellar - A Documentary</h2>
					<p>Sed posuere consectetur est at lobortis. Morbi leo risus, porta ac consectetur ac, vestibulum at eros.</p>
					<button type="button" class="learn_more">LEARN MORE</button>
				</div>
			</div>
		</div>
	</body>
</html>